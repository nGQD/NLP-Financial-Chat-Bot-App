import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
 
sentence_1="Natural language processing is becoming important since soon we will begin talking to our computers."
sentence_2="If computers understand natural language, they will become much simpler to use."

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# Stop word removal
stop_words = set(stopwords.words('english'))

s1 = [w for w in word_tokenize(sentence_1) if not w.lower() in stop_words]
s2 = [w for w in word_tokenize(sentence_2) if not w.lower() in stop_words]

from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()

# Lemmatization
_s1 = [lemmatizer.lemmatize(w) for w in s1]
_s2 = [lemmatizer.lemmatize(w) for w in s2]

_s2.remove(".")
_s2.remove(",")

s1 = " ".join(_s1[:-1]) + s1[-1]
s2 = " ".join(_s2[:-1]) + s2[-1]

print(s1, s2, sep="\n")

# Vocabulary
CountVec = CountVectorizer(ngram_range=(1,1),
                           stop_words='english')
Count_data = CountVec.fit_transform([s1, s2])
cv_dataframe=pd.DataFrame(Count_data.toarray(), columns=CountVec.get_feature_names_out())
print(cv_dataframe)

# Bigram and Trigram
bigram = list(nltk.bigrams(_s2))
trigram = list(nltk.trigrams(_s2))

print(bigram, len(bigram))
print(trigram, len(trigram))