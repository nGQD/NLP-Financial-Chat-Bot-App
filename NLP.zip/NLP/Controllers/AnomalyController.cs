﻿using Common;
using Object;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Web;

namespace PCAnomaly.Controllers
{
    public class AnomalyController : Controller
    {
        public ActionResult Index()
        {
            return null;
        }

    

        #region PCA
        
        [HttpPost, AllowCrossSite]
        public ContentResult PCA_getUsage(string entity, string i1, string i2)
        {
            
            StringBuilder sb = new StringBuilder();
            try
            {
                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("PCName", i1),
                    new KeyValuePair<string, object>("Date", i2)
                };

                sb.Append("{\"data\":[");
                sb.Append(new GlobalVariables().ExecuteProcedure(entity, "SP_PCA_GET_USG", true, _param));
                sb.Append("]}");
            }
            catch
            {
                sb.Clear();
            }
            return Content(String.Format("{0}({1});", "usg", sb.ToString()), "application/json");
        }

        [HttpPost, AllowCrossSite]
        public ContentResult PCA_getApp(string entity, string i1, string i2)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("PCName", i1),
                    new KeyValuePair<string, object>("Date", i2)
                };

                sb.Append("{\"data\":[");
                sb.Append(new GlobalVariables().ExecuteProcedure(entity, "SP_PCA_GET_APP", true, _param));
                sb.Append("]}");
            }
            catch
            {
                sb.Clear();
            }
            return Content(String.Format("{0}({1});", "app", sb.ToString()), "application/json");
        }


        [HttpPost, AllowCrossSite]
        public ContentResult PCA_getLog(string entity, string i1, string i2)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("PCName", i1),
                    new KeyValuePair<string, object>("Date", i2)
                };

                sb.Append("{\"data\":[");
                sb.Append(new GlobalVariables().ExecuteProcedure(entity, "SP_PCA_GET_LOG", true, _param));
                sb.Append("]}");
            }
            catch
            {
                sb.Clear();
            }
            return Content(String.Format("{0}({1});", "log", sb.ToString()), "application/json");
        }
        

        [HttpPost, AllowCrossSite]
        public ContentResult PCA_getEvent(string entity, string i1, string i2)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("Elog", HttpUtility.UrlDecode(i1))
                };
                var x = HttpUtility.UrlDecode(i1);
                _param.Add(new KeyValuePair<string, object>("Date", i2));

                sb.Append("{\"data\":[");
                sb.Append(new GlobalVariables().ExecuteProcedure(entity, "SP_PCA_GET_EVT", true, _param));
                sb.Append("]}");
            }
            catch
            {
                sb.Clear();
            }
            return Content(String.Format("{0}({1});", "evt", sb.ToString()), "application/json");
        }

        
        [HttpPost]
        public ContentResult PCA_getStats(string entity, string i1, string i2, string i3, string i4, string i5, string i6)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("Date", i1),
                    new KeyValuePair<string, object>("ThresW", i2),
                    new KeyValuePair<string, object>("ThresD", i3),
                    new KeyValuePair<string, object>("ThresS", i4),
                    new KeyValuePair<string, object>("HighRiskPC", i5),
                    new KeyValuePair<string, object>("GlobalEvent", i6)
                };

                sb.Append("{\"data\":[");
                sb.Append(new GlobalVariables().ExecuteProcedure(entity, "SP_PCA_GET_STATS", true, _param));
                sb.Append("]}");
            }
            catch
            {
                sb.Clear();
            }
            return Content(String.Format("{0}({1});", "stats", sb.ToString()), "application/json");
        }

        
        [HttpPost]
        public ContentResult PCA_setStats()
        {
            var serializer = new JavaScriptSerializer();
            try
            {
                Stream req = Request.InputStream;
                string JSONString = new StreamReader(req).ReadToEnd();
                serializer.RegisterConverters(new[] { new DynamicJsonConverter() });
                dynamic data = serializer.Deserialize(JSONString, typeof(object));

                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("Date", data.i1),
                    new KeyValuePair<string, object>("PCName", data.i2),
                    new KeyValuePair<string, object>("CFree", data.i3),
                    new KeyValuePair<string, object>("CTotal", data.i4),
                    new KeyValuePair<string, object>("DFree", data.i5),
                    new KeyValuePair<string, object>("DTotal", data.i6),
                    new KeyValuePair<string, object>("CPU", data.i7),
                    new KeyValuePair<string, object>("RAM", data.i8),
                    new KeyValuePair<string, object>("Network", data.i9),
                    new KeyValuePair<string, object>("DiskRead", data.i10),
                    new KeyValuePair<string, object>("DiskWrite", data.i11),
                    new KeyValuePair<string, object>("DiskTransfer", data.i12),
                    new KeyValuePair<string, object>("Temperature", data.i13),
                    new KeyValuePair<string, object>("Inference", data.i14),
                    new KeyValuePair<string, object>("App", data.i15),
                    new KeyValuePair<string, object>("Label", data.i16)
                };

                new GlobalVariables().ExecuteProcedure(data.entity, "SP_PCA_SET_STATS", false, _param);
            }
            catch
            {
            }
            return Content("", "application/json");
        }
        
        
        [HttpPost]
        public ContentResult PCA_setElogs()
        {
            var serializer = new JavaScriptSerializer();
            try
            {
                Stream req = Request.InputStream;
                string JSONString = new StreamReader(req).ReadToEnd();
                serializer.RegisterConverters(new[] { new DynamicJsonConverter() });
                dynamic data = serializer.Deserialize(JSONString, typeof(object));

                List<KeyValuePair<string, object>> _param = new List<KeyValuePair<string, object>>
                {
                    new KeyValuePair<string, object>("Date", data.i1),
                    new KeyValuePair<string, object>("PCName", data.i2),
                    new KeyValuePair<string, object>("Source", data.i3),
                    new KeyValuePair<string, object>("Level", data.i4),
                    new KeyValuePair<string, object>("ErrorLog", data.i5)
                };

                new GlobalVariables().ExecuteProcedure(data.entity, "SP_PCA_SET_ELOGS", false, _param);
            }
            catch
            {
            }
            return Content("", "application/json");

        }
        #endregion


        #region SIDE_FUNCTIONS
        private void LogError(string module, string section, string msg)
        {
            string Path = Server.MapPath("~/Logs");
            if (!Directory.Exists(Path)) Directory.CreateDirectory(Path);

            if (Directory.Exists(Path))
            {
                using (StreamWriter File = new StreamWriter(Path + @"\" + module + "_" + DateTime.Now.ToString("yyyyMMdd") + ".log", false))
                {
                    File.WriteLine(string.Concat("[", DateTime.Now.ToString("HH:mm:ss"), string.IsNullOrWhiteSpace(section) ? "" : " | " + section, "] - ", msg));
                }
            }
        }
        #endregion
    }

    public class AllowCrossSiteAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            filterContext.RequestContext.HttpContext.Response.AddHeader("Access-Control-Allow-Origin", "*");
            base.OnActionExecuting(filterContext);
        }
    }
}