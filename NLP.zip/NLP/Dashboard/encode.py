import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer

import warnings
warnings.filterwarnings("ignore")

THRESHOLD = .9


MODEL = SentenceTransformer('all-MiniLM-L6-v2')
DF = pd.read_csv(r"train_X.tsv", sep="\t")
TEXT = MODEL.encode(DF["text"], batch_size=128)
DF["text"] = TEXT.tolist()
DF.to_csv(r"train_X_encoded.tsv", index=False, sep="\t")