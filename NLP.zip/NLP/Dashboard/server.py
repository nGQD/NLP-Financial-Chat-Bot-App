from flask import Flask, request
from flask_cors import CORS
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer
from waitress import serve

import warnings
warnings.filterwarnings("ignore")

THRESHOLD = .5

app = Flask(__name__)
CORS(app)

@app.route('/chat/', methods=['POST'])
def chat():
    arg = MODEL.encode(str(request.get_data()))
    
    cos_sim = arg.dot(TEXT.T) / (np.linalg.norm(arg) * np.sqrt(np.einsum('ij,ij->i', TEXT, TEXT)))
    output = LABEL[np.argmax(np.where(cos_sim >= THRESHOLD, cos_sim, 0))]
    print(max(cos_sim))
    return output if max(cos_sim) >= THRESHOLD and str(output) != "nan" else "Please reach out to our service desk human experts or visit the nearest branch for further assistance."

if __name__ == "__main__":
    MODEL = SentenceTransformer('all-MiniLM-L6-v2')
    TEXT = np.genfromtxt(r"train_X_encoded.tsv", skip_header=1, dtype=np.float16, delimiter=",")
    LABEL = np.genfromtxt(r"train_y_response.tsv", skip_header=1, dtype=str, encoding=None, delimiter="\n")
    print("Connection Ready")
    serve(app, port="5000")