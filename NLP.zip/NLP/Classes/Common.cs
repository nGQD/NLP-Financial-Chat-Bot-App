﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.Configuration;
using Ini;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Object;

namespace Common
{
    public class GlobalVariables
    {
        IniFile ini = new IniFile(((System.Web.HttpContext.Current == null)
            ? System.Web.Hosting.HostingEnvironment.MapPath("~/")
            : System.Web.HttpContext.Current.Server.MapPath("~/")) + @"Common\keeper.ini");

        public string ConnStr(string entity)
        {
            string UID, PWD, HOST, DB, DBConnStr;
            UID = ini.IniReadValue("Common", "Key_A3"); // cpu
            PWD = ini.IniReadValue("Common", "Key_A4"); // cpu
            //PWD = Decrypt(ini.IniReadValue("Common", "Key_A4"), true);
            HOST = ini.IniReadValue("Common", "Key_A1"); // localhost
            DB = ini.IniReadValue("Common", "Key_A2"); // CPU

            DBConnStr = "Persist Security Info=False;User ID=" + UID + ";Password=" + PWD + ";Server=" + HOST + ";Initial Catalog=" + DB;
            return DBConnStr;
        }

        #region SHARED FUNCTION
        public string ExecuteProcedure(string entity, string command)
        {
            return ExecuteProcedure(entity, command, true);
        }
        public string ExecuteProcedure(string entity, string command, bool output)
        {
            return ExecuteProcedure(entity, command, output, null);
        }
        public string ExecuteProcedure(string entity, string command, bool output, List<KeyValuePair<string, object>> _params)
        {
            return ExecuteProcedure(entity, command, output, _params, CommandType.StoredProcedure);
        }
        public string ExecuteProcedure(string entity, string command, bool output, List<KeyValuePair<string, object>> _params, CommandType cmdtype)
        {
            StringBuilder sb = new StringBuilder();
            using (SqlConnection conn = new SqlConnection(new GlobalVariables().ConnStr(entity)))
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = cmdtype;
                cmd.CommandText = command;
                cmd.CommandTimeout = (600000);
                if (_params != null)
                {
                    foreach (var obj in _params)
                    {
                        var sql_param = new SqlParameter(obj.Key, obj.Value);
                        sql_param.SqlDbType = SqlDbType.NVarChar;
                        cmd.Parameters.Add(sql_param);
                    }
                }

                if (output)
                {
                    using (SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        int rowCount = 0;
                        while (reader.Read())
                        {
                            sb.Append("{");
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                sb.Append("\"" + reader.GetName(i) + "\":\"" + reader[i].ToString() + "\",");
                            }

                            // strip off trailing coma
                            if (reader.FieldCount > 0)
                                sb.Remove(sb.Length - 1, 1);
                            sb.Append("},");
                            rowCount++;
                        }

                        //remove trailing coma
                        if (rowCount > 0)
                            sb.Remove(sb.Length - 1, 1);
                    }
                }
                else
                {
                    cmd.ExecuteNonQuery();
                }
                conn.Close();
            }
            return sb.ToString();
        }


        #endregion

    }
}